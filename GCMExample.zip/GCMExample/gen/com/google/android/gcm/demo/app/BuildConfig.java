/** Automatically generated file. DO NOT MODIFY */
package com.google.android.gcm.demo.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}